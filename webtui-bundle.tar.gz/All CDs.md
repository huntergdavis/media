
| Title | Artist |
| ----- | ------ |
| 7 | S Club 7 |
| 1989 | Taylor Swift |
| #1's | Mariah Carey |
| (What's The Story) Morning Glory? | Oasis (2) |
| *NSYNC | NSYNC |
| ...And Out Come The Wolves | Rancid |
| 10 Things I Hate About You (Music From The Motion Picture) | Various |
| 101.9 The Mix: Mixclusives - Unique Performances From Mix Artists | Various |
| 12 Disney Favorites Doggone Fun Songs | Various |
| 1989 (Taylor's Version) | Taylor Swift |
| 1989 (Taylor's Version) | Taylor Swift |
| 1989 (Taylor's Version) | Taylor Swift |
| 1989 (Taylor's Version) | Taylor Swift |
| 1997 Sony Music Monthly Sampler Vol. 5 | Various |
| 1999: Forward 'Til Death | Various |
| 200 Cigarettes - Music From The Motion Picture | Various |
| 2003 (18 Tracks From The Year's Best Albums) | Various |
| 2015 Grammy Nominees | Various |
| 5,000,000* | Dread Zeppelin |
| 5,000,000* | Dread Zeppelin |
| 60s Love | Various |
| 8-Bit Guy Soundtrack Vol 1 | Various |
| 90s Girls Night Out | Various |
| 90s Movie Hits Collected | Various |
| A Christmas Together | John Denver & The Muppets |
| A Hangover You Don't Deserve | Bowling For Soup |
| A Hard Day's Night | The Beatles |
| A Kind Of Magic | Queen |
| A Little Bit Of Broadway | Julie Andrews |
| A Place In The World | Mary Chapin Carpenter |
| A Place In The World | Mary Chapin Carpenter |
| A Poet's Life | Tim Armstrong |
| A Taste Of Chicago Lo-Cal Punk | Various |
| A Tower Records Tribute To The Beatles | Various |
| A Year Without Rain | Selena Gomez and the Scene |
| Abbey Road | The Beatles |
| ABC Soap Love Affair | Various |
| Absolutely '90s | Various |
| Add It Up (1981-1993) | Violent Femmes |
| Afterglow Live | Sarah McLachlan |
| Aladdin (Original Motion Picture Soundtrack) | Alan Menken, Howard Ashman, Tim Rice |
| Alapalooza | Weird Al Yankovic |
| Alapalooza | Weird Al Yankovic |
| All Saints | All Saints |
| All The Best From The Caribbean | Unknown Artist |
| All The Way... A Decade Of Song | Céline Dion |
| All Things Must Pass | George Harrison |
| Alternative Summer | Various |
| American Beauty | The Grateful Dead |
| American Idiot | Green Day |
| American Idol Season 4: The Showstoppers | Various |
| Amish Paradise | Weird Al Yankovic |
| Amputechture | The Mars Volta |
| Anastasia (Music From The Motion Picture) | David Newman |
| Anthem Of The Sun | The Grateful Dead |
| Anthology 1 | The Beatles |
| Anthology 2 | The Beatles |
| Appeal To Reason | Rise Against |
| Armitage 3 Movie Soundtrack | Various |
| Armitage 3 Movie Soundtrack Cybermatrix | Various |
| Army Of Darkness (Original Motion Picture Soundtrack) | Joseph LoDuca / Danny Elfman |
| Arnold Original Soundtracks - Great Music From The Films Of Arnold Schwarzenegger | Various |
| As Good As Dead | Local H |
| Austin Powers - The Spy Who Shagged Me (Music From The Motion Picture) | Various |
| Austin Powers: International Man Of Mystery (Original Soundtrack) | Various |
| Automatic For The People | R.E.M. |
| Back and White Night | Roy Orbison |
| Back Back | Blondie / Pat Benatar |
| Back To The Future (Music From The Motion Picture Soundtrack) | Various |
| Bangerz | Miley Cyrus |
| Barb Wire (Original Motion Picture Soundtrack) | Various |
| Bat Out Of Hell | Meat Loaf |
| Batman Forever (Music From The Motion Picture) | Various |
| Batman Forever: Motion Picture Score Album | Elliot Goldenthal |
| Baywatch | Various |
| Beatles For Sale | The Beatles |
| Beauty And The Beast (An Original Walt Disney Records Soundtrack) | Alan Menken, Howard Ashman |
| Beauty And The Beast (Original Motion Picture Soundtrack) | Alan Menken, Howard Ashman |
| Beavis And Butt-Head Do America - Original Motion Picture Soundtrack | Various |
| Bedazzled (Original Motion Picture Soundtrack) | Various |
| Bend It Like Beckham (Music From The Motion Picture) | Various |
| Benny & Joon (Music From The Original Motion Picture Soundtrack) | Rachel Portman |
| Bernadette Peters Loves Rodgers & Hammerstein | Bernadette Peters |
| Beverly Hills, 90210 - The Soundtrack | Various |
| Beyond Rangoon (Original Motion Picture Soundtrack) | Hans Zimmer |
| Big Ones | Aerosmith |
| Bigger, Better, Faster, More! | 4 Non Blondes |
| Bite Back / Live At The Crocodile Cafe | Various |
| Black and White Night | Roy Orbison |
| Blade Runner | Vangelis |
| Blaze of Glory: Inspired By The Film Young Guns II | Jon Bon Jovi |
| Blind Man's Zoo | 10,000 Maniacs |
| Blue Banisters | Lana Del Rey |
| Blues For Allah | The Grateful Dead |
| Boogie Nights - Music From The Original Motion Picture | Various |
| Borders Rock Essentials Volume 4 | Various |
| Bored Generation | Various |
| Born On A Pirate Ship | Barenaked Ladies |
| Born To Die | Lana Del Rey |
| Born To Die (The Paradise Edition) | Lana Del Rey |
| Brave And Crazy | Melissa Etheridge |
| Bringing Down The Horse | The Wallflowers |
| Britney | Britney Spears |
| Brokedown Palace Music From The Original Motion Picture Soundtrack | Various |
| Buffy The Vampire Slayer (The Album) | Various |
| Bugs Bunny On Broadway (Original Broadway Recording) | The Warner Bros. Studio Orchestra, George Daugherty |
| But Here We Are | Foo Fighters |
| Butterfly | Mariah Carey |
| Candlebox | Candlebox |
| Carmina Burana | Seattle Choral Company & Orchestra |
| Cartoon Medley | Various |
| Casper (Music From The Motion Picture Soundtrack) | James Horner |
| Cats | Cats Original London Cast |
| Cats Don't Dance (Original Motion Picture Soundtrack) | Various |
| Celebrity Skin | Hole (2) |
| Chaos And Creation In The Backyard | Paul McCartney |
| Chef Original Motion Picture Soundtrack | Various |
| Chemistry | Kelly Clarkson |
| Chemtrails Over The Country Club | Lana Del Rey |
| Chicago - Our Kind Of Town | Various |
| Chicago, The Musical | Various |
| Children Of Dune (Original Television Soundtrack) | Brian Tyler |
| Christmas With The Chipmunks | The Chipmunks |
| Circle Of Friends (Music From The Motion Picture) | Michael Kamen |
| City Of Angels (Music From The Motion Picture) | Various |
| Clash On Broadway | The Clash |
| Classics at the Movies 1-3 | Various |
| Cleveland Rocks! Music From The Drew Carey Show | Various |
| Club Mix '98 | Various |
| Clueless - Original Motion Picture Soundtrack | Various |
| Combat Rock | The Clash |
| Combat Rock | The Clash |
| Come Poop With Me | Triumph The Insult Comic Dog |
| Common Thread: The Songs Of The Eagles | Various |
| Conan The Barbarian (Original Motion Picture Soundtrack) | Basil Poledouris |
| Conan The Barbarian 3D | Tyler Bates |
| Concert For George | Various |
| Conspiracy Of One | The Offspring |
| Contraband | Velvet Revolver |
| Cool Runnings (Music From The Motion Picture) | Various |
| Core | Stone Temple Pilots |
| Cosmic Thing | The B-52's |
| Country Sings Disney | Various |
| Crucial Music: 1977 Revisited | The Clash |
| Cruel Intentions (Music From The Original Motion Picture Soundtrack) | Various |
| Cry Like a Rainstorm, Howl like the Wind | Linda Ronstadt |
| Daydream | Mariah Carey |
| De-Loused In The Comatorium | The Mars Volta |
| Dead Man On Campus (Music From The Motion Picture) | Various |
| Deadpool 2 (Original Motion Picture Soundtrack) | Various |
| Death Becomes Her | Alan Silvestri |
| Deltron 3030 | Deltron |
| Deltron Event 2 (4010) | Del the Funky Homosapien |
| Deluxe | Better Than Ezra |
| Deluxe | Better Than Ezra |
| Dexter's Laboratory: The Musical Time Machine | Various |
| Diana, Princess Of Wales Tribute | Various |
| Disney's Greatest Volume 2 | Various |
| Disney's Phineas and Pherb Holiday Favorites | Various |
| Disney's Rascal Songs, Volume 2 | Various |
| Distant Relatives | Nas & Damian Marley |
| Dizzy Up The Girl | Goo Goo Dolls |
| Dogma: Music From The Motion Picture | Howard Shore |
| Don Duan Demarco Original Motion Picture Soundtrack | Various |
| Dont smile at Me | Billie Eilish |
| Dookie | Green Day |
| Dope-Guns-'N-Fucking In The Streets (Volumes 4-7) | Various |
| Dr Dre Detox Files | Dr Dre |
| Dragon Ball Soundtrack | Various |
| Drawn Together: The Uncensored Soundtrack | Drawn Together Cast |
| Dreams on Toast | The Darkness |
| Drunk At The Stone Balloon | Love Seed Mama Jump |
| Drunk Enough To Dance | Bowling For Soup |
| Dumb And Dumber (Original Motion Picture Soundtrack) | Various |
| Dune™ Original Soundtrack Recording | Toto |
| Empire Records - The Soundtrack | Various |
| Encino Man (Music From The Original Motion Picture Soundtrack) | Various |
| Encomium: A Tribute To Led Zeppelin | Various |
| Entertainment Weekly - The Greatest Hits 1990 | Various |
| Escapology | Robbie Williams |
| Escapology | Robbie Williams |
| ESPN Presents Jock Jams Volume 2 | Various |
| ESPN Presents Jock Rock 2000 | Various |
| Eternally Grateful | The Grateful Dead |
| Europe '72 | The Grateful Dead |
| Europe '72 | The Grateful Dead |
| Evan And Jaron | Evan And Jaron |
| Even More Dazed And Confused (Music From The Motion Picture) | Various |
| Evil Dead - Original Motion Picture Soundtrack | Roque Baños |
| Evil Dead The Musical (Original Cast Recording) | Various |
| Falconaires | The United States Air Force Band of the Rockies |
| Falling Into You | Céline Dion |
| Fallout From The Phil Zone | The Grateful Dead |
| Family Values Tour '98 | Various |
| Fantastic 4 The Album | Various |
| Fantastic 4 The Album | Various |
| Fear | Toad The Wet Sprocket |
| Fearless | Taylor Swift |
| FF VIII Music Collection: Music From The Final Fantasy® VIII Video Game | Nobuo Uematsu |
| FF Violin VI | TAMUSIC |
| Final Fantasy: The Spirits Within (Original Motion Picture Soundtrack) | Elliot Goldenthal |
| Find It On The Wings | Sandi Patty |
| Fly | Dixie Chicks |
| Forever Blue | Chris Isaac |
| Forever Blue | Chris Isaak |
| Forrest Gump (The Soundtrack) | Various |
| Forrest Gump (The Soundtrack) | Various |
| Forty Licks | The Rolling Stones |
| Frances The Mute | The Mars Volta |
| Franz Ferdinand | Franz Ferdinand |
| Franz Ferdinand | Franz Ferdinand |
| Freakin' At The Freakers Ball | Shel Silverstein |
| Friends | Various |
| Frog And Toad Audio Collection | Arnold Lobel |
| From the Pyre | The Last Dinner Party |
| From Under The Cork Tree | Fall Out Boy |
| Fumbling Towards Extasy | Sarah McLachlan |
| Fun Home (A New Broadway Musical) | Various |
| Funky Divas | En Vogue |
| GAP - Favorite Songs (Fall 2005) | Various |
| Garbage | Garbage |
| Garden State (Music From The Motion Picture) | Various |
| Garfield Am I Cool Or What? | Various |
| Gaslighter | Dixie Chicks |
| German Beer Drinking Songs | Gerhard Scholz Band |
| Ghost World (Original Motion Picture Soundtrack) | Various |
| Give 'Em The Boot | Various |
| Glee: The Music, Volume 1 | Glee Cast |
| Go (Music From The Motion Picture) | Various |
| Go Ahead Punk ... Make My Day | Various |
| Go Simpsonic With The Simpsons: More Original Music From The Television Series | The Simpsons |
| Go To Heaven | The Grateful Dead |
| Golden Throats: The Great Celebrity Sing-Off! | Various |
| Goldeneye (Original Motion Picture Soundtrack) | Eric Serra |
| Gordon | Barenaked Ladies |
| Gourmandises | Alizée |
| Grandma's Boy : Music From The Motion Picture | Various |
| Grease (The Original Soundtrack From The Motion Picture) | Various |
| Greased | Less Than Jake |
| Great Expectations The Album | Various |
| Greatest Hits | Aerosmith |
| Greatest Hits | Willie Nelson |
| Grooves Volume Eleven | Various |
| Grosse Pointe Blank (More Music From The Film) | Various |
| Grosse Pointe Blank Soundtrack | Various |
| Hackers (Original Motion Picture Soundtrack) | Various |
| Hamilton Original Broadway Cast Recording | Various |
| Hangin' Tough | New Kids On The Block |
| Harry Potter And The Chamber Of Secrets (Music From And Inspired By The Motion Picture) | John Williams (4) |
| Harry Potter And The Prisoner Of Azkaban (Original Motion Picture Soundtrack) | John Williams (4) |
| Haunted | Poe |
| Have Yourself A Funky Holiday - Contemporary Holiday Music Selections | Various |
| Heart And Soul (New Songs From Ally McBeal) | Vonda Shepard |
| Heathers - Original Motion Picture Soundtrack | David Newman |
| Heavy Metal 2000 Original Motion Picture Soundtrack | Various |
| Heavy Metal: Motion Picture Soundtrack | Various, Sammy Hagar, Devo |
| Heide Sez (Lookout Records 1996 Sampler CD) | Various |
| Hello | Poe |
| Hercules: The Legendary Journeys | Joseph LoDuca |
| Higher Learning: Music From The Motion Picture | Various |
| Highlander - The Final Dimension | Michael Kamen, Stewart Copeland, Peter Robinson |
| Highlander: The TV Show Soundtrack Volume 2 | Various |
| Hold The Girl | Rina Sawayama |
| Holiday Hits | Unknown Artist |
| Hooray For Boobies | Bloodhound Gang |
| Hot | Squirrel Nut Zippers |
| Hot Cakes | The Darkness |
| Hot Rod - Music From The Motion Picture | Various |
| I'm Outta Love | Anastacia |
| In My Tribe | 10,000 Maniacs |
| In The Dark | The Grateful Dead |
| In The Heights: Original Broadway Cast Recording | Lin-Manuel Miranda |
| In The Meantime, In Between Time | The Party |
| In Through The Out Door | Led Zeppelin |
| Indestructible | Rancid |
| Indiana Jones And The Last Crusade (Original Motion Picture Soundtrack) | John Williams (4) |
| Iron Man 3 Heroes Fall (Music Inspired By The Motion Picture) | Various |
| Is This It | The Strokes |
| It's Now Or Never: The Tribute To Elvis | Various |
| Jams Volume 5 | Radio Disney |
| Jay And Silent Bob Strike Back (Music From The Motion Picture) | Various |
| Jersey Boys (Original Broadway Cast Recording) | Jersey Boys Original Broadway Cast |
| Jock Jams Volume 5 | Various |
| Judge Dredd (Original Motion Picture Soundtrack) | Various |
| Kellogg's Classic Rock | The Police / Bryan Adams |
| KFOG's Local Scene 2 | Various |
| Kill Bill Vol. 2 (Original Soundtrack) | Various |
| Kindred Spirits / A Tribute To The Songs Of Johnny Cash | Various |
| Kingpin (Original Motion Picture Soundtrack) | Various |
| KMTT New Music Sampler 2004 | Various |
| Labyrinth (From The Original Soundtrack Of The Jim Henson Film) | David Bowie And Original Score By Trevor Jones |
| Lady In Satin | Billie Holiday |
| Lana Del Rey A.K.A. Lizzy Grant | Lana Del Rey |
| Last Of Our Kind | The Darkness |
| LateNightTales | The Flaming Lips |
| Legends Of Tomorrow - Season 1 (Original Television Soundtrack) | Blake Neely |
| Les Misérables - The Original London Cast Recording | Alain Boublil And Claude-Michel Schönberg |
| Lesbian Favorites: Women Like Us | Various |
| Let Go | Avril Lavigne |
| Let It Be... Naked | The Beatles |
| Let's Talk About Love | Celine Dion |
| Lexx: The Series | Marty Simon |
| Like A Girl, I Want You To Keep Coming | Various |
| Lilith Fair (A Celebration Of Women In Music) | Various |
| Little Earthquakes | Tori Amos |
| Live At KEXP, Volume Four | Various |
| Live At KEXP, Volume Three | Various |
| Live At The BBC | The Beatles |
| Live At The Gorge 05/06 | Pearl Jam |
| Live At The Greek | Jimmy Page & The Black Crowes |
| Live From Bonnaroo 2003 | Various |
| Live From Central Park | Sheryl Crow And Friends Of Sheryl Crow |
| Live From The Archives 10 | Various |
| Live From The Archives 17 | Various |
| Live In Hamburg '62 | The Beatles |
| Live On Letterman (Music From The Late Show) | Various |
| Liz Phair | Liz Phair |
| Local.101 Volume One | Various |
| London Calling | The Clash |
| London Calling | The Clash |
| Louis L'Amour Collection | Willie Nelson, Johnny Cash, Kris Kristofferson, Waylon Jennings |
| Love Actually (Original Motion Picture Soundtrack) | Various |
| Love.Angel.Music.Baby. | Gwen Stefani |
| M!ssundaztood | P!nk |
| Mac + Devin Go To High School (Music From And Inspired By The Movie) | Snoop Dogg & Wiz Khalifa |
| Mad Men - A Musical Companion (1960-1965) | Various |
| Madonna | Madonna |
| Mamma Mia | A*Teens |
| Mandy Moore | Mandy Moore |
| Mario and Chill | Helynt |
| Mario and Chill | Helynt |
| Mayhem | Lady Gaga |
| Mean Girls, Music From The Motion Picture | Various |
| Medusa | Annie Lennox |
| Mega Pop Dance Hits 6 | Dziewczynag |
| Melissa Etheridge | Melissa Etheridge |
| Melrose Place - The Music | Various |
| Memory Almost Full | Paul McCartney |
| Memory almost full | Paul McCartney |
| Mentos: The Freshmaker Tour | Various |
| Merry Christmas Animaniacs Loony Tunes | Various |
| Methods Of Mayhem | Methods Of Mayhem (2) |
| Mexican Dinner Party Music | Various |
| Millennium | Backstreet Boys |
| Mixclusives Volume 4 | Various |
| MOJO The Best of 2024 | Various |
| Monster | R.E.M. |
| Monty Python Sings | Monty Python |
| More Than You Think You Are | Matchbox Twenty |
| Mothership | Led Zeppelin |
| Motorheart | The Darkness |
| Move This! | Various |
| MTV Party To Go Volume 6 | Various |
| MTV Unplugged | 10,000 Maniacs |
| MTV Unplugged | Alanis Morissette |
| MTV Unplugged | Alice In Chains |
| MTV Unplugged EP | Mariah Carey |
| MTV's Amp 2 | Various |
| Music For Little Hipsters | Various |
| Music For The Jilted Generation | The Prodigy |
| Music From And Inspired By The Motion Picture Avengers Assemble | Various |
| Music From Chicago Cab | Various |
| Music From The Motion Picture Dreamgirls | Various |
| Music From The Motion Picture Goldmember | Various |
| Music From The Motion Picture Phenomenon (John Travolta) | Various |
| Music From The Motion Picture Pulp Fiction | Various |
| Music From The Motion Picture Pulp Fiction | Various |
| Music From The Motion Picture The Rugrats Movie | Various |
| Music From The Motion Picture Wayne's World | Various |
| Music From The OC: Mix 2 | Various |
| Music Of Pink Floyd (Orchestral Maneuvers) | David Palmer (2) And Royal Philharmonic Orchestra |
| Musical Mischief! | Baby Looney Tunes |
| My So-Called Life - Music From And Inspired By | Various |
| NBC Celebrity Christmas | Various |
| Never enough | Melissa Etheridge |
| Never Enough | Melissa Etheridge |
| Nevermind | Nirvana |
| New Miserable Experience | Gin Blossoms |
| Newsies | Alan Menken, Jack Feldman |
| Nickel Creek | Nickel Creek |
| Nightshades | Cobra Starship |
| Nirvana | Nirvana |
| No Boundaries (A Benefit For The Kosovar Refugees) | Various |
| No Strings Attached | NSYNC |
| No. 10, Upping St. | Big Audio Dynamite |
| Northwest's Heavy Hitters | Various |
| Not Another Teen Movie: Music From The Motion Picture | Various |
| Notting Hill (Music From The Motion Picture) | Various |
| Notting Hill (The Original Motion Pictures Soundtrack) | Various |
| Now In A Minute | Donna Lewis |
| Now That's What I call Music 31 | Various |
| Now That's What I Call Music! 13 | Various |
| Now That's What I Call Music! 14 | Various |
| Now That's What I Call Music! 2 | Various |
| NOW That's What I Call Music! 25th Anniversary Volume 1 | Various |
| Now That's What I Call Music! 37 | Various |
| Now That's What I Call Music! 6 | Various |
| Now That's What I Call Music! 8 | Various |
| NOW That's What I Call Music! 87 | Various |
| NOW That's What I Call Music! 88 | Various |
| Now That’s What I Call Music! ‘90s Pop | Various |
| Number One Hits | Tim McGraw |
| Odelay | Beck |
| Office Space (The Motion Picture Soundtrack) | Various |
| OK Go | OK Go |
| Old & In The Way | Old & In The Way |
| Old School Friday: More Music From The Original Motion Picture | Various |
| Old School Friday: More Music From The Original Motion Picture | Various |
| On The Mountain 5 | Various |
| One Fierce Beer Coaster | Bloodhound Gang |
| One More Time... | Blink-182 |
| One Piece Piano Symphony | One Piece Live Orchestra |
| One Way Ticket To Hell ...And Back | The Darkness |
| ONXRT: Live From The Archives Vol. 15 | Various |
| ONXRT: Live From The Archives Vol. 5 | Various |
| ONXRT: Live From The Archives Vol. 7 | Various |
| ONXRT: Live From The Archives Volume 11 | Various |
| ONXRT: Live From The Archives Volume 8 | Various |
| ONXRT: Live From The Archives, Vol. 4 | Various |
| Opera for people who hate Opera | Various |
| Ophelia | Natalie Merchant |
| Our Time In Eden | 10,000 Maniacs |
| Our Time In Eden | 10,000 Maniacs |
| Pancho, Lefty And Rudolph | Merle Haggard And Willie Nelson |
| Party Tyme Karaoke - Super Hits 3 | Unknown Artist |
| PDX Pop Now! 2005 | Various |
| Pebbles Vol. 1 Original 60s Punk and Psych Classics | Various |
| Permission To Land | The Darkness |
| Personal File | Johnny Cash |
| Peter Pan Live! | Various |
| Playback | Tom Petty And The Heartbreakers |
| Pleasantville Music from the Motion Picture | Various |
| Pokemon the first Movie Soundtrack | Various |
| Pool Of Radiance: Ruins Of Myth Drannor (Original Game Soundtrack) | Andrew Boyd (2), Robb Mills |
| Psychédélices | Alizée |
| Pull My Finger! | Unknown Artist |
| Pulp Fiction (Music From The Motion Picture) | Various |
| Pure | Paul McCartney |
| Purple | Stone Temple Pilots |
| Q101 - Live101 Volume 2 | Various |
| Quake | Nine Inch Nails |
| Radio Free Music Vol. 2 | Various |
| Rare On Air (Live Performances Vol. One) | Various |
| Reality Bites (Original Motion Picture Soundtrack) = 四個畢業生 電影原聲帶 | Various |
| Reckoning | The Grateful Dead |
| Red Dirt Girl | Emmylou Harris |
| Reflections From Broadway | John Barrowman |
| Reggae Gold 1999 | Various |
| Regions Of Light And Sound Of God | Jim James |
| Ren & Stimpy - Radio Daze | Ren & Stimpy (2) |
| Rent - Original Broadway Cast Recording | Jonathan Larson |
| Reputation | Taylor Swift |
| Revamped | Demi Lovato |
| Revolver | The Beatles |
| Revolver Reloaded (Mojo Presents Their 1966 Masterpiece Covered In Full) | Various |
| Road Rash 3D: The Album | Various |
| Robin Hood: Men In Tights (Music From The Original Motion Picture Soundtrack) | Hummie Mann |
| Rock 'N' Roll Meltdown | Various |
| Rockabye Baby! (Lullaby Renditions Of The Eagles) | Michael Armstrong |
| Rockabye Baby! Lullaby Renditions Of Coldplay | Michael Armstrong |
| Rocket | Primitive Radio Gods |
| Rockferry | Duffy |
| Romeo Must Die | Various |
| Romy And Michele's High School Reunion (Original Soundtrack) | Various |
| Rufus Wainwright | Rufus Wainwright |
| Running With Scissors | Weird Al Yankovic |
| S Club | S Club 7 |
| Saturday Morning (Cartoons' Greatest Hits) | Various |
| Savage Garden | Savage Garden |
| School Of Rock (Music From And Inspired By The Motion Picture) | Various |
| Schoolhouse Rock! Rocks | Various |
| Schoolmates '95 | Various |
| Search & Destroy (15 Explosive Tracks By Bands Who Were Punk Before Punk) | Various |
| Seattle Music Scene Volume One | Various |
| Seattle Supersonics | The Presidents of the United States of America |
| Sesame Street: Bert And Ernie's Greatest Hits | Bert & Ernie |
| Sex And The City (Music From The HBO Series) | Various |
| Sgt. Pepper's Lonely Hearts Club Band | The Beatles |
| Shadow Of The Beast - The Soundtracks | David Whittaker, Tim & Lee Wright |
| Shady Grove | Jerry Garcia, David Grisman |
| Shantae And The Seven Sirens Official Soundtrack | Gavin Allen, Mark Sparling, Prof. Sakamoto |
| Shaun Of The Dead (Music From The Motion Picture) | Various |
| Sherlock Holmes (Original Score From The Granada TV Series) | Patrick Gowers, St. Paul's Cathedral Choir, The Gabrieli String Quartet, The Wren Orchestra |
| Shum Ticky | Laura Love |
| SID Dreams | Chaos Generator |
| Siegfried & Roy At The Mirage - Dreams & Illusions | Various |
| Sing When You're Winning | Robbie Williams |
| SiriusXM: Comedy Records Presents 10 Year | Comedy Records |
| Ska Wars | Various |
| Sky Blue Sky | Wilco |
| Sky High: Original Soundtrack | Various |
| Small Soldiers (Music From The Motion Picture) | Various |
| Smash | The Offspring |
| Smoke And Fire | Lord Sutch And Heavy Friends |
| SNL25  - Saturday Night Live, The Musical Performances | Various |
| So I Married An Axe Murderer | Various |
| Soda Fountain Favorites: Early Rock-N-Roll Jukebox | Various |
| Songs Of Anarchy: Music From Sons Of Anarchy Seasons 1-4 | Various |
| Songs Of The Sarah Silverman Program - From Our Rears To Your Ears! | Sarah Silverman |
| Songs That Got Us Through WWII | Various |
| SOS | La Bouche |
| Sounds Of Portland | Various |
| Space Ghost's Surf & Turf | Space Ghost |
| Spaced Out (The Very Best Of..) | Leonard Nimoy & William Shatner |
| Spawn The Album | Various |
| Speak | Lindsay Lohan |
| Speak Now | Taylor Swift |
| Speak Now (Taylor's Version) | Taylor Swift |
| Speakerboxxx / The Love Below | OutKast |
| Spend The Night | The Donnas |
| Spiceworld | Spice Girls |
| Spider-Man: Across The Spider-Verse (Soundtrack From And Inspired By The Motion Picture) | Metro Boomin |
| Spider-man: Turn Off The Dark | Various |
| Stage Heroes | Colm Wilkinson, London Philharmonic Orchestra |
| Stand Still, Look Pretty | The Wreckers |
| Star Trek Sound Effects | Various |
| Star Trek ® :The Astral Symphony | Various |
| Star Trek: Deep Space Nine - From The Original Episode The Emissary (Music From The Original Television Soundtrack) | Dennis McCarthy |
| Star Trek: First Contact (Original Motion Picture Soundtrack) | Jerry Goldsmith |
| Star Trek: The Next Generation Volume Three (Music From The Original Television Soundtrack) | Dennis McCarthy |
| Star Wars: A New Hope Sountrack | John Williams |
| Starlight Express - Deutsche Originalaufnahme | Andrew Lloyd Webber |
| Starship Troopers (Original Motion Picture Soundtrack) | Basil Poledouris |
| Starship Troopers (Original Motion Picture Soundtrack) | Basil Poledouris |
| Stay Awake - Various Interpretations Of Music From Vintage Disney Films | Various |
| Step Back In time: The Best of Kylie Minogue | Kylie Minogue |
| Stockings by the Fire - A Starbucks Holiday | Various |
| Stormy Weather | Various |
| Streetcore | Joe Strummer & The Mescaleros |
| Streets Of Rage 4 Original Soundtrack | Olivier Deriviere |
| Stripped | Christina Aguilera |
| Stunt | Barenaked Ladies |
| Stupid | Toad The Wet Sprocket |
| Super Bad Super Black. Can Y'All Dig That? | Various |
| Super Hits | Toad The Wet Sprocket |
| Super Mario Galaxy Official Soundtrack | Mario Galaxy Orchestra |
| Superunknown | Soundgarden |
| Supposed Former Infatuation Junkie | Alanis Morissette |
| Sweet Home Alabama (Original Motion Picture Soundtrack) | Various |
| Sweet Valley High (Songs From The TV Series) | Various |
| Sweetheart (Love Songs) | Various |
| Tails | Lisa Loeb & Nine Stories |
| Take Offs And Landings | Rilo Kiley |
| Tales From The Crypt Presents: Demon Knight (Original Motion Picture Soundtrack) | Various |
| Talk On Corners | The Corrs |
| Tank Girl - Original Soundtrack From The United Artists Film | Various |
| Television's Greatest Hits (65 TV Themes! From The 50's And 60's) | Various |
| That Darn Punk Original Motion Picture Soundtrack | Various |
| That Thing You Do! - Original Motion Picture Soundtrack | Various |
| The All-Time Greatest Hits Of Roy Orbison | Roy Orbison |
| The Animaniacs Go Hollywood | Animaniacs |
| The Beatles | The Beatles |
| The Bedlam In Goliath | The Mars Volta |
| The Best Of Arlo Guthrie | Arlo Guthrie |
| The Best of Hanna Barbara Tunes from the Toons | Various |
| The Best of the Great Girl Singers | Various |
| The Best Of: Skeletons From The Closet | The Grateful Dead |
| The Best Tracks From The Best Albums Of 1998 | Various |
| The Bob's Burgers Music Album | Bob's Burgers |
| The Bodyguard (Original Soundtrack Album) | Whitney Houston |
| The Book Of Mormon (Original Broadway Cast Recording) | Trey Parker, Robert Lopez, Matt Stone |
| The Burlington Northern | Tom Daily |
| The Chronicles of Narnia: Prince Caspian Abridged | Various |
| The Chronicles Of Riddick (Original Motion Picture Soundtrack) | Graeme Revell |
| The Colour of Love | Celine Dion |
| The Complete Tom Jones | Tom Jones |
| The coulour of my love | Celine Dion |
| The Crow (Original Motion Picture Soundtrack) | Various |
| The Cubbies Are Rockin' | Various |
| The Distance To Here | Live |
| The Distant Future | Flight Of The Conchords |
| The Distant Future | Flight of the Conchords |
| The Downward Spiral | Nine Inch Nails |
| The E.N.D | Black Eyed Peas |
| The Early Beatles | The Beatles |
| The Ego Has Landed | Robbie Williams |
| The Essential Clash | The Clash |
| The Essential Electric Light Orchestra | Electric Light Orchestra |
| The Fame Monster | Lady Gaga |
| The Full Monty | Various |
| The Gift Of Game | Crazy Town |
| The Great Fantasy Adventure Album | Erich Kunzel and Cincinnati Pops |
| The Heist | Macklemore and Ryan Lewis |
| The Hitchhiker's Guide To The Galaxy (Original Soundtrack) | Various, Joby Talbot |
| The Hobbit The Desolation of Smaug | Howard Shore |
| The Immaculate Collection | Madonna |
| The Last DJ | Tom Petty And The Heartbreakers |
| The Legend Of Zelda: Breath Of The Wild Sound Selection | Manaka Kataoka, Yasuaki Iwata, Hajime Wakai |
| The Life of a Showgirl | Taylor Swift |
| The Lord Of  The Rings: The Two Towers (Original Motion Picture Soundtrack) | Howard Shore |
| The Lord Of The Rings: The Fellowship Of The Ring | Howard Shore |
| The Lord Of The Rings: The Return Of The King | Howard Shore |
| The Man With The Iron Fists - Original Motion Picture Soundtrack | Various |
| The Mountain Summer 2000 CD Sampler | Various |
| The Muppet Show: Music, Mayhem, And More (The 25th Anniversary Collection) | The Muppets |
| The Music of Grand Theft Auto IV | Various Artists |
| The Music Of Smash | SMASH Cast |
| The New Mel Brooks Musical Young Frankenstein - Original Broadway Cast Recording | Various |
| The Pagemaster (Original Motion Picture Soundtrack) | James Horner, London Symphony Orchestra |
| The Phantom Of The Opera: The Original Motion Picture Soundtrack | Andrew Lloyd Webber |
| The Players: Powered By Fender | Various |
| The Premier Collection - The Best Of Andrew Lloyd Webber | Andrew Lloyd Webber |
| The Princess Diaries Original Soundtrack | Various |
| The Producers - The New Mel Brooks Musical (Original Broadway Cast Recording) | The Producers Original Broadway Cast |
| The Radius Preview | Allen Stone (2) |
| The Real Thing: Words And Sounds Vol. 3 | Jill Scott |
| The Roof Of The World | Doctor Who |
| The Scarlet Pimpernel | Linda Eder, Chuck Wagner, Dave Clemmons (2), Peabo Bryson |
| The Secret Garden - The Original Broadway Cast Album | Lucy Simon, Marsha Norman |
| The Sign | Ace of Base |
| The Sound Of Music (An Original Soundtrack Recording) | Various |
| The SpongeBob SquarePants Movie (Music From The Movie And More...) | Various |
| The Story Of The Clash Volume 1 | The Clash |
| The Thomas Crown Affair (Music From The MGM Motion Picture) | Various, Bill Conti |
| The Three Musketeers (Original Motion Picture Soundtrack) | Michael Kamen |
| The Unauthorized Biography Of Reinhold Messner | Ben Folds Five |
| The Unplugged Collection: Volume One | Various |
| The Unplugged Collection: Volume One | Various |
| The Very Best Of Elvis Costello And The Attractions | Elvis Costello & The Attractions |
| The Very Best of Sheryl Crow | Sheryl Crow |
| The Waterboy (Original Soundtrack) | Various |
| The Wedding Singer (Music From The Motion Picture) | Various |
| The Wedding Singer Volume 2 | Various |
| The Wishing Chair | 10,000 Maniacs |
| The Writing's On The Wall | Destiny's Child |
| The X-Files: The Album | Various |
| Third Eye Blind | Third Eye Blind |
| This Is Me...Then | Jennifer Lopez |
| This Is Us (Songs From Where You Live) | Various |
| Three Cheers For Sweet Revenge | My Chemical Romance |
| Thug Mentality 1999 | Krayzie Bone |
| Tidal | Fiona Apple |
| Tigerlily | Natalie Merchant |
| Titanic (Music From The Motion Picture) | James Horner |
| Top Of The World Tour - Live | Dixie Chicks |
| Trailer Park Boys: The Movie Soundtrack | Various |
| Trigun: The 2nd Donut Happy Pack | Tsuneo Imahori |
| Trio | Dolly Parton, Linda Ronstadt, Emmylou Harris |
| Triple J's Hottest 100 Volume 23 | Various |
| Tron Legacy R3C0NF1GUR3D | Daft Punk |
| Tubthumper | Chumbawamba |
| Un-Led-Ed | Dread Zeppelin |
| Unplugged | Eric Clapton |
| Uptown MTV Unplugged | Various |
| Urban Hymns | The Verve |
| Vans Off The Wall CD Volume III | Various |
| Vans Warped Tour (2002 Tour Compilation) | Various |
| Varsity Blues - Music From And Inspired By The Motion Picture | Various |
| VH1 Divas Live | Divas (6) |
| VH1 Divas Live/99 | Various |
| VH1 Presents The Corrs Live In Dublin | The Corrs |
| VH1 Storytellers | Johnny Cash & Willie Nelson |
| Vibrate - The Best Of Rufus Wainwright | Rufus Wainwright |
| Video Games Live (Volume One) | Various |
| Vitalogy (生命学) | Pearl Jam |
| Vol. 3: (The Subliminal Verses) | Slipknot |
| We're A Happy Family - A Tribute To Ramones | Various |
| We're A Happy Family - A Tribute To Ramones | Various |
| Welcome Interstate Managers | Fountains of Wayne |
| What Hits!? | Red Hot Chili Peppers |
| What's Up Doc? (Can We Rock?) | Fu-Schnickens With Shaquille O'Neal |
| What's Your Name? | Adam Sandler |
| When Bush Comes to Shove | Capitol Steps |
| When Folk Meets Rock: The Saga Of A Sound | Various |
| Where Music Meets Film (Live From Sundance Film Festival) | Various |
| Whip-Smart | Liz Phair |
| White: Melodies Of Final Fantasy Tactics Advance | Hitoshi Sakimoto, Nobuo Uematsu, 大越香里, Ayako Saso |
| Whitechocolatespaceegg | Liz Phair |
| Whitney Houston | Whitney Houston |
| Whoa, Nelly! | Nelly Furtado |
| Wicked (Original Broadway Cast Recording) | Stephen Schwartz |
| Wide Open Spaces | Dixie Chicks |
| Wildflowers | Tom Petty |
| William Shakespear's Romeo + Juliet (Music From The Motion Picture) | Various |
| Willow (Original Motion Picture Soundtrack) | James Horner |
| Wonders of the World | Long Beach Dub All Stars |
| Woodstock 94 | Various |
| Woodstock 99 | Various |
| Workingman's Dead | The Grateful Dead |
| World Clique | Deee-Lite |
| World Music Radio | Jon Batiste |
| World Wrestling Federation The Music | Various |
| Wrecking Ball | Emmylou Harris |
| Wrecking Ball | EmmyLou Harris |
| WWII Radio | Bing Crosby |
| Xanadu From the Original Motion Picture Soundtrack | Various |
| Yakko's World | Animaniacs |
| You Eediot! | Ren & Stimpy (2) |
| You're A Good Man, Charlie Brown: The New Broadway Cast Recording | Various |
| Young Guns II | Alan Silvestri |
| Yourself Or Someone Like You | Matchbox Twenty |
| Zombies! Aliens! Vampires! Dinosaurs! | Hellogoodbye |
| Zoolander  (Music From The Motion Picture) | Various |
| ¡Viva La Cobra! | Cobra Starship |
| ワンピース ベスト ソング コレクション = One Piece Best Song Collection | Various |
